# Order processing app

This is a modified version of the Order Processing app from Module 13 <https://github.com/CorndelWithSoftwire/DevOps-Course-Workshop-Module-13-Learners>.

You will have been given access to a resource group in Azure containing a running the Python app from this repo and an SQL database.
You shouldn't need to update the existing App Service and will instead be deploying this app to AKS.
