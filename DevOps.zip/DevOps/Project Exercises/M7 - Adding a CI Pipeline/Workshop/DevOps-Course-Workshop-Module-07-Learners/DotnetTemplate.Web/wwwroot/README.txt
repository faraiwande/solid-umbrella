﻿Do not add files directly to the css/ or js/ folder.

Files in these folders are compiled from Styles/ and Scripts/ respectively.
