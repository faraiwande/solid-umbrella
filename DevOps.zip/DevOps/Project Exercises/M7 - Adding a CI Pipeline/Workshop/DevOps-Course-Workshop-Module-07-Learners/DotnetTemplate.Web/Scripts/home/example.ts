export function functionOne() {
  console.log('Hello world!');
}

export function functionTwo() {
  console.log('Hello world again!');
}
